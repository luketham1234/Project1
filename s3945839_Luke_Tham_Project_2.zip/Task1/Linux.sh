#!/bin/bash

#Author: Luke Tham (s3945839)
#Date: 8/11/2023
#
#Script to update Linux computers
#

echo "rmit1234" | sudo -S apt-get update >> /home/luketham/Documents/Project2/Task1/Linux.log
